public interface ICalculator
{
    public double CalculateArea();
}
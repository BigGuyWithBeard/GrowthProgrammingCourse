﻿namespace Paints.Library.Tests
{
    [TestClass]
    public sealed class TestUserQuantity
    {
        [TestMethod]
        public void TestItemGet()
        {
            throw new NotImplementedException();

        }

        [TestMethod]
        public void TestUser_Get()
        {
            throw new NotImplementedException();

        }

        [TestMethod]
        public void TestQuantityGet()
        {
            throw new NotImplementedException();

        }
    }
}

﻿namespace Paints.Library.Tests
{
    [TestClass]
    public sealed class TestSprayItem
    {
        //[TestMethod]
        //public void TestMethod1()
        //{
        //    throw new NotImplementedException();

        //}
    }
}

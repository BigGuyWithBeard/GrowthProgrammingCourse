﻿namespace Paints.Library.Tests
{
    [TestClass]
    public sealed class TestPaintItem
    {
        //[TestMethod]
        //public void TestMethod1()
        //{
        //    throw new NotImplementedException();

        //}
    }
}

﻿namespace Paints.Library.Tests
{
    [TestClass]
    public sealed class TestTuftItem
    {
        //[TestMethod]
        //public void TestMethod1()
        //{
        //    throw new NotImplementedException();

        //}
    }
}
